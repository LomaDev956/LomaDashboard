
"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CircleSlash } from "lucide-react";

// This page is no longer in use and can be removed.
// The Point of Sale functionality has been deferred for a future version.
export default function DeprecatedPosPage() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
            <CircleSlash className="h-6 w-6 text-muted-foreground"/>
            Punto de Venta no Disponible
        </CardTitle>
        <CardDescription>
          Esta funcionalidad ha sido desactivada temporalmente y se considerará para una futura versión de la aplicación.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground">
          La gestión del inventario se realiza desde la sección "Herramientas".
        </p>
      </CardContent>
    </Card>
  );
}
