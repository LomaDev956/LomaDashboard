
"use client";

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Loader2 } from 'lucide-react';

// This page is no longer in use and can be removed.
// The application now routes directly to the dashboard.
export default function DeprecatedLoginPage() {
  const router = useRouter();

  useEffect(() => {
    router.replace('/loma-dashboard');
  }, [router]);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-background text-foreground p-6">
      <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
      <p className="text-lg text-muted-foreground">Redirigiendo al dashboard...</p>
    </div>
  );
}
